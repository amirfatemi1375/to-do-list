import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-MNH3YG7V.js";
import "./chunk-K2GQEYGN.js";
import "./chunk-2FXVGBRF.js";
import "./chunk-YPLDNPIF.js";
import "./chunk-6GJSICTM.js";
import "./chunk-2M7TMZGM.js";
import "./chunk-YRBYSGPE.js";
import "./chunk-RJ3YFNFW.js";
import "./chunk-SXNLII4N.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
