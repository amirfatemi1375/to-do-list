import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-GOBM47KO.js";
import "./chunk-K2GQEYGN.js";
import "./chunk-UTBRZREU.js";
import "./chunk-XLPP43XS.js";
import "./chunk-NWWV73NQ.js";
import "./chunk-2FXVGBRF.js";
import "./chunk-ETHBINFC.js";
import "./chunk-YPLDNPIF.js";
import "./chunk-6GJSICTM.js";
import "./chunk-2M7TMZGM.js";
import "./chunk-YRBYSGPE.js";
import "./chunk-RJ3YFNFW.js";
import "./chunk-SXNLII4N.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
