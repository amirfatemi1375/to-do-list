import {
  MatDivider,
  MatDividerModule
} from "./chunk-QHXFDG5O.js";
import "./chunk-YPLDNPIF.js";
import "./chunk-6GJSICTM.js";
import "./chunk-2M7TMZGM.js";
import "./chunk-YRBYSGPE.js";
import "./chunk-RJ3YFNFW.js";
import "./chunk-SXNLII4N.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
