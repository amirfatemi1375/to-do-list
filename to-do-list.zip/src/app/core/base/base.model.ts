export interface baseModel {
  title: string;
  date: string;
}
