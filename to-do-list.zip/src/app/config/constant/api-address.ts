//task
export const TASK = 'tasks';
//mainList
export const MAIN_LIST = 'mainList';
