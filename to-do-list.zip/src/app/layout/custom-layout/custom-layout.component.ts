import { Component } from '@angular/core';

@Component({
  selector: 'app-custom-layout',
  templateUrl: './custom-layout.component.html',
  styleUrl: './custom-layout.component.scss'
})
export class CustomLayoutComponent {

}
